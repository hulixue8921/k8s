# Monitoring the Ingress Controller Using Prometheus

This doc is now available at https://docs.nginx.com/nginx-ingress-controller/logging-and-monitoring/prometheus/