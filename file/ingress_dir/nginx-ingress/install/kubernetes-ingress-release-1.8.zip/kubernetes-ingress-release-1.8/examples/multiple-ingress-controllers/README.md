# Using Multiple Ingress Controllers

This example has been transformed into the [Multiple Ingress Controllers doc](https://docs.nginx.com/nginx-ingress-controller/installation/running-multiple-ingress-controllers/).
