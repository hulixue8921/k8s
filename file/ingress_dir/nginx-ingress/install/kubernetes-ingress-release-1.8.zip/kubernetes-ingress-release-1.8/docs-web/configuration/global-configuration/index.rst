Global Configuration
====================

.. toctree::
   :maxdepth: 2

   configmap-resource
   command-line-arguments
   custom-templates
   reporting-resources-status
   globalconfiguration-resource
